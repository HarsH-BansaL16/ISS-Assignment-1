declare -a arr
sed 's/,/ /g' < input.txt > input2.txt
read -a arr < input2.txt

for ((i=0 ; i<${#arr[@]} ; i++))
do
	for ((j=0 ; j<${#arr[@]}-1 ; j++))
	do
		if [[ ${arr[$j]} -gt ${arr[$j+1]} ]]
		then
			temp=${arr[$j+1]}
			let arr[$j+1]=${arr[$j]}
			let arr[$j]=$temp
		fi
	done
done
echo ${arr[@]}
rm -r input2.txt
