#!/bin/bash
# filename='quotes.txt'

# while read -r line;
# do
#     if [ "$line" = "" ];
#     then
#         continue
#     else
#         echo $line >> output.txt
#     fi
# done < $filename
# mv "output.txt" "quotes.txt"

# PART-A
awk 'NF' quotes.txt 


echo " "

# PART-B
awk '!seen[$0]++' quotes.txt 