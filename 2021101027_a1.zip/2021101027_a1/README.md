<h1>ISS Assignment-1 Submitted by Harsh Bansal</h1>

> Name :- Harsh Bansal

> OS :- MacOS

> Roll No:- 2021101027

> ***GITHUB LINK :- https://github.com/HarsH-BansaL16/ISS-Assignment-1***

- **All the files are already given executable permissions**
- **In 3d,the words are in sorted order**
- **In 4, input is taken through a file "input.txt" and output is printed on terminal**
- **In 5b, subsequent letter for 'z' is 'a' and for 'Z' is 'A'**

> Following is the Tree Structure for the Submission Format.
```
2021101027_a1
|
|__ q1.sh 
|
|__ q2.sh
|
|__ q3.sh
|
|__ q4.sh
|
|__ q5.sh
```