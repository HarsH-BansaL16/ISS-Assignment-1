#!/bin/bash

file=$1

# PART-A
printf "Size of the file in bytes: "
wc -c < $file | awk '{print $1}'

# PART-B
printf "Total number of lines in the file: "
wc -l < $file | awk '{print $1}'

# PART-C
printf "Total number of words in the file: "
wc -w < $file | awk '{print $1}'

touch "tempfile.txt"
tempfile=tempfile.txt

i=1


# PART-D
while read line
do
    echo $line > $tempfile
    printf "Line No. $i - Count of words: "
    cat $tempfile | wc -w | awk '{print $1}'
    let $((i++))
done < $file

rm $tempfile


# PART-E
grep -wo '[[:alnum:]]\+' $file | sort | uniq -c |
while read count word
do
echo ${word}: ${count}
done