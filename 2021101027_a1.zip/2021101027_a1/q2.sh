#!/bin/bash
touch speech.txt

rm -r speech.txt

touch speech.txt

filename='quotes.txt'

while read -r line;
do
    if [ "$line" = "" ];
    then
        echo "" >> speech.txt
    else
        variable1=$(echo $line | cut -d "~" -f 2)

        variable3=$(echo $line | cut -d "~" -f 1)

        variable4=$(echo "$variable1 once said, ")

        echo "$variable4\"$variable3\"">> speech.txt
    fi
done < $filename
