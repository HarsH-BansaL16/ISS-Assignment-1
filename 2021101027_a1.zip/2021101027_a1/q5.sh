#!/bin/bash

# PART-A
read -r line
echo $line | rev


# PART-B
len=${#line}
echo $line | rev | tr 'a-zA-Z' 'b-zA-Za'


# PART-C
let a=${#line}
for (( i=$a/2 - 1 ; i>=0 ; i-- ))
do
	echo -n  ${line:$i:1}
done
for (( i=$a/2 ; i<=${#line} - 1 ; i++ ))
do
	echo -n ${line:$i:1}
done	
echo
